(function(w,d){
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(w,d,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init','1798113991476662');fbq('track','PageView');
var K='align_utm',P=['utm_source','utm_medium','utm_campaign','utm_content','utm_term','utm_id','fbclid'];
try{var q=new URLSearchParams(location.search),o={},h=0;P.forEach(function(k){var v=q.get(k);if(v){o[k]=v.slice(0,200);h=1;}});
if(h){o.landing_page=location.pathname;o.landing_date=new Date().toISOString().slice(0,10);var j=JSON.stringify(o);try{sessionStorage.setItem(K,j);}catch(e){}try{localStorage.setItem(K,j);}catch(e){}}}catch(e){}
w.alignUtm=function(){var j=null;try{j=sessionStorage.getItem(K);}catch(e){}if(!j){try{j=localStorage.getItem(K);}catch(e){}}try{return JSON.parse(j||'{}');}catch(e){return {};}};
setTimeout(function(){try{fbq('trackCustom','engaged_60s');}catch(e){}try{if(w.gtag)gtag('event','engaged_60s',{page_path:location.pathname});}catch(e){}},60000);
})(window,document);
