(function(w,d){
var n=w.fbq=w.fbq||function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!w._fbq)w._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=n.queue||[];
fbq('init','1798113991476662');fbq('track','PageView');
function add(src){var t=d.createElement('script');t.async=!0;t.src=src;d.head.appendChild(t);}
function late(){add('https://connect.facebook.net/en_US/fbevents.js');if(!w.__gtagLoaded){w.__gtagLoaded=1;add('https://www.googletagmanager.com/gtag/js?id=G-XSBW2P9E20');}}
if(d.readyState==='complete'){setTimeout(late,0);}else{w.addEventListener('load',function(){setTimeout(late,0);});}
var K='align_utm',P=['utm_source','utm_medium','utm_campaign','utm_content','utm_term','utm_id','fbclid'];
try{var q=new URLSearchParams(location.search),o={},h=0;P.forEach(function(k){var v=q.get(k);if(v){o[k]=v.slice(0,200);h=1;}});
if(h){o.landing_page=location.pathname;o.landing_date=new Date().toISOString().slice(0,10);var j=JSON.stringify(o);try{sessionStorage.setItem(K,j);}catch(e){}try{localStorage.setItem(K,j);}catch(e){}}}catch(e){}
w.alignUtm=function(){var j=null;try{j=sessionStorage.getItem(K);}catch(e){}if(!j){try{j=localStorage.getItem(K);}catch(e){}}try{return JSON.parse(j||'{}');}catch(e){return {};}};
setTimeout(function(){try{fbq('trackCustom','engaged_60s');}catch(e){}try{if(w.gtag)gtag('event','engaged_60s',{page_path:location.pathname});}catch(e){}},60000);
})(window,document);
