(function(w,d){
var n=w.fbq=w.fbq||function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!w._fbq)w._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=n.queue||[];
fbq('init','1798113991476662');fbq('track','PageView');
function add(src){var t=d.createElement('script');t.async=!0;t.src=src;d.head.appendChild(t);}
function late(){add('https://connect.facebook.net/en_US/fbevents.js');if(!w.__gtagLoaded){w.__gtagLoaded=1;add('https://www.googletagmanager.com/gtag/js?id=G-XSBW2P9E20');}}
if(d.readyState==='loading'){d.addEventListener('DOMContentLoaded',function(){setTimeout(late,0);});}else{setTimeout(late,0);}
var K='align_utm',P=['utm_source','utm_medium','utm_campaign','utm_content','utm_term','utm_id','fbclid'];
try{var q=new URLSearchParams(location.search),o={},h=0;P.forEach(function(k){var v=q.get(k);if(v){o[k]=v.slice(0,200);h=1;}});
if(h){o.landing_page=location.pathname;o.landing_date=new Date().toISOString().slice(0,10);var j=JSON.stringify(o);try{sessionStorage.setItem(K,j);}catch(e){}try{localStorage.setItem(K,j);}catch(e){}}}catch(e){}
w.alignUtm=function(){var j=null;try{j=sessionStorage.getItem(K);}catch(e){}if(!j){try{j=localStorage.getItem(K);}catch(e){}}try{return JSON.parse(j||'{}');}catch(e){return {};}};
/* Microsoft Clarity: inert until CLARITY_ID is set. Forms are masked. */
var CLARITY_ID='zeftztpruu';
if(CLARITY_ID){try{d.addEventListener('DOMContentLoaded',function(){[].forEach.call(d.querySelectorAll('form'),function(f){f.setAttribute('data-clarity-mask','True');});});
(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src='https://www.clarity.ms/tag/'+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);})(w,d,'clarity','script',CLARITY_ID);}catch(e){}}
function sv(){try{if(!('IntersectionObserver' in w))return;var ss=d.querySelectorAll('.page.on > section');if(!ss.length)return;var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;io.unobserve(e.target);var x=e.target,i=[].indexOf.call(ss,x)+1,l=x.querySelector('.label,.ps-title,h1,h2'),t=(l?l.textContent:'').replace(/\s+/g,' ').trim().slice(0,60);try{if(w.gtag)gtag('event','section_view',{section_index:i,section_label:t,page_path:location.pathname});}catch(_){}});},{rootMargin:'0px 0px -40% 0px',threshold:0});for(var k=0;k<ss.length;k++)io.observe(ss[k]);}catch(e){}}
if(d.readyState==='loading'){d.addEventListener('DOMContentLoaded',sv);}else{sv();}
function area(a){if(a.closest('.stickybar,.acta-bar'))return 'sticky';if(a.closest('header,.sb,.sb-mob,.mobmenu'))return 'header';if(a.closest('footer'))return 'footer';return 'content';}
d.addEventListener('click',function(e){try{var a=e.target&&e.target.closest&&e.target.closest('a[href]');if(!a)return;var h=a.getAttribute('href')||'',k=null;
if(/^tel:/i.test(h))k='phone';else if(/^mailto:/i.test(h))k='email';else if(/(^|\/)contact(\.html)?(#|$|\?)|#check$|#feasibility$/.test(h))k='cta';if(!k)return;
var p={cta_type:k,cta_text:(a.textContent||'').replace(/\s+/g,' ').trim().slice(0,60),cta_area:area(a),link_url:h.slice(0,100),page_path:location.pathname};
if(w.gtag)gtag('event','cta_click',p);
if(k==='cta')fbq('trackCustom','cta_click',{cta_area:p.cta_area,page_path:p.page_path});else fbq('track','Contact',{content_name:k});}catch(_){}},true);
setTimeout(function(){try{fbq('trackCustom','engaged_60s');}catch(e){}try{if(w.gtag)gtag('event','engaged_60s',{page_path:location.pathname});}catch(e){}},60000);
})(window,document);
